function num_only(){
  if((event.keyCode<48) || (event.keyCode>57)) {
    event.returnValue=false;
  }
}

// 이미지 오버 공통 함수
function imgOver(oImg){
	var reg = new RegExp('_off');
	oImg.src = oImg.src.replace(reg,'_on');
}
// 이미지 아웃 공통 함수
function imgOut(oImg){
	var reg = new RegExp('_on');
	oImg.src = oImg.src.replace(reg,'_off');
} 

// 삭제 검사 확인
function del(href){
	if(confirm("한번 삭제한 자료는 복구할 방법이 없습니다.\n\n정말 삭제하시겠습니까?")) {
		document.location.href = encodeURI(href);
	}
}

//지역선택
function getLocation(ID,sido,gugun) {
	if(sido) {
		$.ajax({
			url:"/program/company/getLocation.php?SIDO="+encodeURI(sido)+"&GUGUN=" + encodeURI(gugun) + "&ID=" + ID,
			success:function(data) {
				$("#" + ID).html(data);
			}
		});
	}
}

//숫자만 입력
function onlyNumber(e) {
	if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
		// Allow: Ctrl+A
			(e.keyCode == 65 && e.ctrlKey === true) ||
		// Allow: home, end, left, right
			(e.keyCode >= 35 && e.keyCode <= 39)) {
		// let it happen, don't do anything
		return;
	}
	// Ensure that it is a number and stop the keypress
	if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
		e.preventDefault();
	}
}

//인풋박스 클릭시 value값 삭제
function Change (target,type){
	if ( target.value == target.defaultValue && type==0) target.value = '';
	if ( !target.value && type==1) target.value = target.defaultValue;
}

//게시판 카테고리 연결
function category_link(val){
	location.href="?category="+encodeURI(val);
}

// 아이디/비번 찾기
function member_find(){
	window.open('/member/find.php', 'popup', 'width=450, height=300, status=no, toolbar=no, menubar=no, directories=no, location=no');
}

	
//- 엔터키
jQuery.fn.enterKey = function(fnNm) {
	jQuery(this).bind("keydown", function(e) {
			if (e.keyCode == 13) { // enter key
					eval(fnNm);
					return false
			}
	});
}   


/*
vi_viewcode 영상코드
inval 팝업유무
*/
function fnVodOpen(vi_viewcode, inval){
	/*
	dataType:"jsonp",
					jsonpCallback: "cb",
	*/
			$.ajax({
					type : 'POST',
					url : '/event/ajax_vod_view',
					data: "vi_viewcode="+vi_viewcode,
					dataType:"json",
					success : function(result){
						if(result.alert == "Y" ){
							alert(result.html);
						}else{
							if(inval == "popup"){
	
	
								if(result.vi_popup == "pop"){
									var iWidth = 1200;
									var iHeight = 700;
									var iLeft = (window.screen.availWidth - iWidth) / 2;
									var iTop = (window.screen.availHeight - iHeight) / 2;
	
									var nwin=window.open("", "naverVod", "height="+ iHeight+ ",width=" + iWidth + ",top=" + iTop + ",left=" + iLeft + ",toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=no");
									nwin.document.write(result.html)
								}else{
										var f = document.createElement("div");
										var f_sub = document.createElement("div");
	
										var dd = document.createElement("div");
										dd.setAttribute('id',"_vod");
										document.body.appendChild(dd);
	
										$(f).html("<div id='_layer_video-box' style='overflow:hidden;'>"+result.html+"</div>");
										$(f_sub).html('<div id="_layer_video-bg"><p class="close" onclick="_close_pop();"><i class="xi-close-thin pointer"></i></p></div>');
										//- 스크립트를 넣고
										$("#_vod").html("<style>"
											+"#_layer_video-box {width: 1200px;height: 700px;background: #fff;position: fixed;left: 50%;top: 50%;transform: translate(-50%,-50%);z-index: 999;overflow-X: hidden;}"
											+"#_layer_video-bg {background: #000;position: fixed;left: 0;top: 0;z-index: 100;width: 100vw;height: 100vh;opacity: 0.7;overflow: hidden;z-index: 998;}"
										+"</style>")
										//- 영상을 넣고
										
										$("#_vod").html($("#_vod").html()+$(f).html()+$(f_sub).html())
										//- 안에 있는 영상을show한다.
										$("#_vod").show().find("div").show();
										//- 영상 제외 블럭을 클릭하면 숨겨진다.
										$("#_layer_video-bg").click(function(){
											$("#_layer_video-bg").hide();
											$("#_layer_video-box").hide().html("");
										})
								}
	
							}else{
								$(inval).html(result.html);
							}
						}
					},
				});
	
	
	
		}
	
		$.fn.onlyNumber = function(){
			this.css("ime-mode", "disabled");
			this.keypress(function(event){		
					if(event.which && (event.which < 48 || event.which > 57) ) {
							event.preventDefault();
					}
			}).keyup(function(){
					if(jQuery(this).val() != null && jQuery(this).val() != '' ) {
							jQuery(this).val(jQuery(this).val().replace(/[^0-9]/g, '') );
					}
			});
	};
	
